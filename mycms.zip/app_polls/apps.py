from django.apps import AppConfig


class AppPollsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_polls'
